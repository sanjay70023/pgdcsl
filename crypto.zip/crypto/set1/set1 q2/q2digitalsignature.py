from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization

# Generate RSA private and public keys
def generate_rsa_keys():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )
    public_key = private_key.public_key()
    return private_key, public_key

def sign_message(private_key, message: str) -> bytes:
    """Sign the message with the private key."""
    signature = private_key.sign(
        message.encode(),
        padding.PKCS1v15(),
        hashes.SHA256()
    )
    return signature

def verify_signature(public_key, message: str, signature: bytes) -> bool:
    """Verify the signature with the public key."""
    try:
        public_key.verify(
            signature,
            message.encode(),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        return True
    except:
        return False

# Default message
message = "This is a secret message."

# Generate RSA keys
private_key, public_key = generate_rsa_keys()

# Signing the message
signature = sign_message(private_key, message)
print(f"Generated Signature: {signature.hex()}")

# Verifying the signature
if verify_signature(public_key, message, signature):
    print("Message is authentic and integrity is intact.")
else:
    print("Message has been tampered with!")
