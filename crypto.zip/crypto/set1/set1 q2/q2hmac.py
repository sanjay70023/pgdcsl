import hmac
import hashlib

# Shared secret key
secret_key = b"supersecretkey"

def create_hmac(message: str) -> str:
    """Generate HMAC for the message."""
    hmac_object = hmac.new(secret_key, message.encode(), hashlib.sha256)
    return hmac_object.hexdigest()

def verify_hmac(message: str, expected_hmac: str) -> bool:
    """Verify the HMAC for the received message."""
    received_hmac = create_hmac(message)
    return hmac.compare_digest(received_hmac, expected_hmac)

# Default message
message = "This is a secret message."

# Creating HMAC
message_hmac = create_hmac(message)
print(f"Generated HMAC: {message_hmac}")

# Verifying HMAC
if verify_hmac(message, message_hmac):
    print("Message is authentic and integrity is intact.")
else:
    print("Message has been tampered with!")
