from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend

def decrypt_aes_128(ciphertext: bytes, key: bytes) -> str:
    # Extract the IV (first 16 bytes) and the actual ciphertext
    iv = ciphertext[:16]
    encrypted_data = ciphertext[16:]
    
    # Create AES cipher in CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    
    # Decrypt the data
    padded_plaintext = decryptor.update(encrypted_data) + decryptor.finalize()
    
    # Remove PKCS#7 padding
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()
    
    return plaintext.decode()

def read_from_file(filename: str) -> bytes:
    with open(filename, 'rb') as f:
        return f.read()

# Example usage:
if __name__ == "__main__":
    # Ask user for the ciphertext file and key
    ciphertext_file = input("Enter the name of the ciphertext file (e.g., ciphertext.txt): ")
    ciphertext = read_from_file(ciphertext_file)  # Read raw binary data
    
    key_input = input("Enter the AES key (16 bytes in ASCII, 128 bits): ")

    # Check if the key is 16 bytes
    if len(key_input) != 16:
        print("Error: Key must be exactly 16 bytes (128 bits).")
    else:
        key = key_input.encode()  # Convert key to bytes
        
        # Decrypt the message
        try:
            decrypted_message = decrypt_aes_128(ciphertext, key)
            print("Decrypted message:", decrypted_message)
        except Exception as e:
            print(f"Error during decryption: {e}")
