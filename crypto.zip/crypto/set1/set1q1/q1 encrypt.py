from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
import os

def encrypt_aes_128(plaintext: str, key: bytes) -> bytes:
    # Generate a random 16-byte IV
    iv = os.urandom(16)
    
    # Pad the plaintext to be a multiple of AES block size (16 bytes)
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(plaintext.encode()) + padder.finalize()

    # Create AES cipher in CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    
    # Encrypt the data
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()

    # Return the IV + ciphertext, because the IV is required for decryption
    return iv + ciphertext

def save_to_file(filename: str, data: bytes):
    with open(filename, 'wb') as f:
        f.write(data)
    print(f"Ciphertext saved to {filename}")

# Example usage:
if __name__ == "__main__":
    # Ask user for plaintext and key
    plaintext = input("Enter the message to encrypt: ")
    key_input = input("Enter the AES key (16 bytes in ASCII, 128 bits): ")

    # Check if the key is 16 bytes
    if len(key_input) != 16:
        print("Error: Key must be exactly 16 bytes (128 bits).")
    else:
        key = key_input.encode()  # Convert key to bytes
        
        # Encrypt the message
        ciphertext = encrypt_aes_128(plaintext, key)
        
        # Save the ciphertext to a file
        save_to_file("ciphertext.txt", ciphertext)
