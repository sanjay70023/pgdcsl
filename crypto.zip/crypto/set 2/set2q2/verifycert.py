# verify_certificate.py
from cryptography.x509 import load_pem_x509_certificate
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
import datetime

def load_certificate(cert_filename):
    with open(cert_filename, "rb") as cert_file:
        cert_data = cert_file.read()
    return load_pem_x509_certificate(cert_data, default_backend())

def verify_certificate(cert_filename):
    # Load the certificate
    cert = load_certificate(cert_filename)

    # Check validity period
    current_time = datetime.datetime.utcnow()
    if current_time < cert.not_valid_before or current_time > cert.not_valid_after:
        print("Certificate is not valid at this time.")
        return False

    # Try to verify the certificate's signature using the public key (this is self-signed)
    try:
        cert.public_key().verify(
            cert.signature,
            cert.tbs_certificate_bytes,
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        print("Certificate signature is valid!")
        return True
    except Exception as e:
        print(f"Signature verification failed: {e}")
        return False

if __name__ == "__main__":
    cert_filename = "my_certificate.pem"  # Path to the certificate to verify
    is_valid = verify_certificate(cert_filename)
    if is_valid:
        print("Certificate verification successful.")
    else:
        print("Certificate verification failed.")
