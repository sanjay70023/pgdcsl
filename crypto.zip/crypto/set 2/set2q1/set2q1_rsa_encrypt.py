# rsa_encrypt.py
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
import binascii

# Step 1: Load the public key (predefined key)
def load_public_key():
    with open("public_key.pem", "rb") as public_file:
        public_key = serialization.load_pem_public_key(
            public_file.read(),
            backend=default_backend()
        )
    return public_key

# Step 2: Encrypt the message with the public key
def encrypt_message(public_key, message: str) -> bytes:
    ciphertext = public_key.encrypt(
        message.encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return ciphertext

# Example usage
if __name__ == "__main__":
    # Load the public key from file
    public_key = load_public_key()

    # Encrypt a message with the public key
    message = "This is a secret message."
    encrypted_message = encrypt_message(public_key, message)
    
    # Save the encrypted message to a file in hexadecimal format
    with open("encrypted_message.txt", "wb") as f:
        f.write(binascii.hexlify(encrypted_message))

    print("Message encrypted and saved to 'encrypted_message.txt'.")
