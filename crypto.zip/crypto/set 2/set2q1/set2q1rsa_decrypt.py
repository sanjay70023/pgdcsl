# rsa_decrypt.py
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
import binascii

# Step 1: Load the private key (predefined key)
def load_private_key():
    with open("private_key.pem", "rb") as private_file:
        private_key = serialization.load_pem_private_key(
            private_file.read(),
            password=None,
            backend=default_backend()
        )
    return private_key

# Step 2: Decrypt the message with the private key
def decrypt_message(private_key, ciphertext: bytes) -> str:
    plaintext = private_key.decrypt(
        ciphertext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return plaintext.decode()

# Example usage
if __name__ == "__main__":
    # Load the private key from file
    private_key = load_private_key()

    # Load the encrypted message from the file
    with open("encrypted_message.txt", "rb") as f:
        encrypted_message_hex = f.read()
        encrypted_message = binascii.unhexlify(encrypted_message_hex)

    # Decrypt the message using the private key
    decrypted_message = decrypt_message(private_key, encrypted_message)

    # Print the decrypted message
    print(f"Decrypted Message: {decrypted_message}")
